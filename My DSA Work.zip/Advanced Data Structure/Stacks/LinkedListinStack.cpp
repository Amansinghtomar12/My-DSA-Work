#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;

    Node(int data)
    {
        this->data = data;
        next = NULL;
    }
};

void push(Node *&top, int d)
{
    Node *temp = new Node(d);
    if (top == NULL)
    {
        top = temp;
    }
    else
    {
        temp->next = top;
        top = temp;
    }
}

void print(Node *top)
{
    Node *temp = top;
    if (temp == NULL)
    {
        cout << "Stack is empty" << endl;
    }
    else
    {
        while (temp != NULL)
        {
            cout << temp->data <<endl;
            temp = temp->next;
        }
    }
}

void peek(Node *top)
{
    if (top == nullptr)
    {
        cout << "Stack is empty" << endl;
    }
    else
    {
        cout << "Top element is: " << top->data << endl;
    }
}

void pop(Node *&top)
{
    if (top != nullptr)
    {
        Node *temp = top;
        top = top->next;
        delete temp;
    }
    else
    {
        cout << "Stack underflow" << endl;
    }
}

int main()
{
    Node *node1 = new Node(10);
    Node *top = node1;

    push(top, 15);
    push(top, 20);
    push(top, 25);
    push(top, 30);

    print(top);
    peek(top);

    pop(top);
    pop(top);
    pop(top);

    print(top);
    peek(top);

    pop(top);    
    pop(top);
    print(top);    
    peek(top);

    return 0;
}
