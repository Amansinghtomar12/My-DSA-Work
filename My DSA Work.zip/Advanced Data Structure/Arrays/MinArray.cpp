#include <iostream>
using namespace std;
class Max
{
    int i, n, min;
    int arr[10];

public:
    void input()
    {
        cout << "Enter the size of your array: " << endl;
        cin >> n;
        cout << "Give your array elements:" << endl;
        for (i = 0; i < n; i++)
        {
            cin >> arr[i];
        }
    }
    void print()
    {
        cout << "Your array is: " << endl;
        for (i = 0; i < n; i++)
        {
            cout << arr[i] << " ";
        }
    }
    void calculate()
    {
        min = arr[0];
        for (i = 1; i < n; i++)
        {
            if (arr[i] < min)
            {
                min = arr[i];
            }
        }
        cout << "Min element of your array is: " << min;
    }
};
int main()
{
    Max obj;
    obj.input();
    obj.print();
    obj.calculate();

    return 0;
}