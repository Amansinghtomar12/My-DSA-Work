#include<iostream>
using namespace std;
class insert{
    int arr[10], n, i, pos, num;
    public:
    void input(){
        cout<<"Enter the number of elements you want to print: ";
        cin>>n;
        cout<<"Enter the elements: "<<endl;
        for(i = 0; i < n-1; i++){
            cin>>arr[i];
        }
            cout<<"Give the position to insert the element: ";
            cin>>pos;
            cout<<"Give the number to print on that position: ";
            cin>>num;
    }
    void output(){
        cout<<"Your array before elements insertion is: "<<endl;
        for(i = 0; i < n-1; i++){
            cout<<arr[i]<<" "<<endl;
        }
    }
    void calculate(){
        for(i = 8; i >= pos - 1; i--){
            arr[i + 1] = arr[i];
        }
        arr[pos - 1] = num;
        cout<<"Your array after elements insertion is: "<<endl;
        for(i = 0; i < n; i++){
            cout<<arr[i]<<" ";
        }

    }
};
int main(){
    insert obj;
    obj.input();
    obj.output();
    obj.calculate();

    return 0;
}