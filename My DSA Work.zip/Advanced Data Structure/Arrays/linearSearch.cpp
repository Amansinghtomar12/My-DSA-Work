#include <iostream>
using namespace std;
class Linear
{
    int arr[10], n, i, key, flag = 0;

public:
    void input()
    {
        cout << "Enter the size of your array: " << endl;
        cin >> n;
        cout << "Enter the elements of your array: " << endl;
        for (i = 0; i < n; i++)
        {
            cin >> arr[i];
        }
    }
    void output()
    {
        cout << "Elements of your array are: " << endl;
        for (i = 0; i < n; i++)
        {
            cout << arr[i] << " ";
        }
        cout << endl;
        cout << "Enter the element you want to search: " << endl;
        cin >> key;
    }
    void calculate()
    {
        for (i = 0; i < n; i++)
        {
            if (arr[i] == key)
            {
                flag = 1;
                break;
            }
        }
        if (flag == 0)
        {
            cout << "Element not found!! " << endl;
        }
        else
        {
            cout << "Element found!! " << endl;
        }
    }
};
int main()
{
    Linear obj;

    obj.input();
    obj.output();
    obj.calculate();

    return 0;
}