#include <iostream>
using namespace std;
class Linear
{
    int arr[10], n, key, flag = 0, mid;

public:
    void input()
    {
        cout << "Enter the size of your array: " << endl;
        cin >> n;
        cout << "Enter the elements of your array: " << endl;
        for (int i = 0; i < n; i++)
        {
            cin >> arr[i];
        }
    }
    void output()
    {
        cout << "Elements of your array are: " << endl;
        for (int i = 0; i < n; i++)
        {
            cout << arr[i] << " ";
        }
        cout << endl;
        cout << "Enter the element you want to search: " << endl;
        cin >> key;
    }
    void calculate()
    {
        int i = 0;
        int j = n - 1;
        while (i <= j)
        {
            mid = (i + j) / 2;
            if (arr[mid] == key)
            {
                flag = 1;
                break;
            }
            if (arr[mid] < key)
            {
                i = mid + 1;
            }
            if (arr[mid] > key)
            {
                j = mid - 1;
            }
        }
        if (flag == 1)
        {
            cout << "Element found!!" << endl;
        }
        else
        {
            cout << "Element not found!!" << endl;
        }
    }
};
int main()
{
    Linear obj;

    obj.input();
    obj.output();
    obj.calculate();

    return 0;
}