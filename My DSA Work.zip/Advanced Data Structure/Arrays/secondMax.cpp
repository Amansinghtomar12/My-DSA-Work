#include <iostream>
using namespace std;
class Max
{
    int i, n, temp, secondtemp;
    int arr[10];

public:
    void input()
    {
        cout << "Enter the size of your array: " << endl;
        cin >> n;
        cout << "Give your array elements:" << endl;
        for (i = 0; i < n; i++)
        {
            cin >> arr[i];
        }
    }
    void print()
    {
        cout << "Your array is: " << endl;
        for (i = 0; i < n; i++)
        {
            cout << arr[i] << " ";
        }
    }
    void calculate()
    {
        temp = arr[0];
        secondtemp = arr[0];
        for (i = 1; i < n; i++)
        {
            if (arr[i] > temp)
            {
                temp = arr[i];
            }
            else if (arr[i] > secondtemp && arr[i] != temp)
            {
                secondtemp = arr[i];
            }
        }
        cout << "Max element of your array is: " << temp << endl;
        cout << "Second Max element of your array is: " << secondtemp;
    }
};
    int main()
    {
        Max obj;
        obj.input();
        obj.print();
        obj.calculate();

        return 0;
    }