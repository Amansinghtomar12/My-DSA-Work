#include <iostream>
using namespace std;
class deleteArray
{
    int arr[10], n, i, val, flag = 0;

public:
    void input()
    {
        cout << "The number of elements you want to enter in the array:" << endl;
        cin >> n;
        cout << "Enter thr elements:" << endl;
        for (i = 0; i < n; i++)
        {
            cin >> arr[i];
        }
        cout << "Enter the element you want to delete: " << endl;
        cin >> val;
    }
    void output()
    {
        cout << "Your array elements before element deletion are: " << endl;
        for (i = 0; i < n; i++)
        {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
    void calculate()
    {
        for (i = 0; i < n; i++)
        {
            if (arr[i] == val)
            {
                flag = 1;
                break;
            }
        }
        if (flag == 0)
        {
            cout << "Element not found!!" << endl;
        }
        else
        {
            for (; i < n - 1; i++)
            {
                arr[i] = arr[i + 1];
            }
            cout << "Your array elements after element deletion are: " << endl;
            for (i = 0; i < n - 1; i++)
            {
                cout << arr[i] << " ";
            }
            cout << endl;
        }
    }
};
int main()
{
    deleteArray obj;
    obj.input();
    obj.output();
    obj.calculate();

    return 0;
}