#include<iostream>
using namespace std;
class Node{
    public:
    int data;
    Node* next;
    Node* previous;
    Node(int data){
        this->previous = NULL;
        this->data = data;
        this->next = NULL;
    }
};

void InsertAtHead(Node *&head,Node *&tail, int d){
   /* if(head == NULL){
        Node *temp = new Node(d);
        head = temp;
        tail = temp; 
        return;
    }*/
    Node* temp = new Node(d);
    temp->next = head;
    head->previous = temp;
    head = temp;
}

void InsertAtTail(Node *&head, Node *&tail, int d){
     /*if(tail == NULL){
        Node *temp = new Node(d);
        head = temp;
        tail = temp;
        return; 
    }*/
    Node* temp = new Node(d);
    tail->next = temp;
    temp->previous = tail;
    tail = temp;
}

void InsertAtPosition(Node *&tail, Node *&head, int pos, int d){
    if(pos == 1){
        InsertAtHead(head, tail, d);
        return;
    }
    Node *temp =  head;
    int count = 1;
    while(count < pos - 1){
        temp = temp->next;
        count++; 
    }
    if(temp->next == NULL){
        InsertAtTail(head, tail, d);
        return;
    }
    Node *nodetoinsert = new Node(d);
    nodetoinsert->next = temp->next;
    temp->next->previous = nodetoinsert;
    temp->next = nodetoinsert;
    nodetoinsert->previous = temp;
}

void print(Node *&head){
    Node* temp = head;
    while(temp != NULL){
        cout<<temp->data<<" ";
        temp = temp->next;
    }
    cout<<endl;
}

int getLength(Node *head){
    int length = 0;
       Node* temp = head;
    while(temp != NULL){
        length++;
        temp = temp->next;
    }
    return length;
}

void deleteNode(Node *&head, Node *&tail, int position){
    if(position == 1){
        Node *temp = head;
        temp -> next -> previous = NULL;
        head = temp->next;
        temp -> next = NULL;
        delete temp;
    }
    else{
        Node *current = head;
        Node *previous = NULL;
        int cnt = 1;
        while(cnt < position){
            previous = current;
            current = current -> next;
            cnt ++;
        }
        current ->previous = NULL;
        previous -> next = current -> next;
        current -> next = NULL;
        delete current;
         if(previous -> next == NULL){
            tail = previous;
        }
    }
}

int main(){
    Node* node1 = new Node(12);
    /*cout<<node1->previous<<" ";
    cout<<node1->data<<" ";
    cout<<node1->next<<endl;*/

    Node* head = node1;
    Node* tail = node1;
    cout<<node1 -> data<<endl;
    InsertAtHead(head,tail, 8);
    print(head);
    InsertAtHead(head,tail, 19);
    print(head);
    InsertAtHead(head,tail, 28);
    print(head);

    InsertAtTail(head,tail, 4);
    print(head);
    InsertAtTail(head,tail, 9);
    print(head);
    InsertAtTail(head,tail, 7);
    print(head);

    InsertAtPosition(tail, head, 7, 77);
    print(head);

    deleteNode(head, tail, 2);
    print(head);

    cout<<"The length of your LinkedList is: "<<getLength(head)<<endl;

    cout<<"Head: "<<head -> data << endl;    
    cout<<"Tail: "<<tail -> data << endl;    


    return 0;
}