#include <iostream>
using namespace std;
class Sorting
{
    int arr[10], i, j, n, temp;

public:
    void input()
    {
        cout << "Enter the size of your array: " << endl;
        cin >> n;
        cout << "Enter the elements of your array: " << endl;
        for (i = 0; i < n; i++)
        {
            cin >> arr[i];
        }
    }
    void output()
    {
        cout << "Elements of your array are: " << endl;
        for (i = 0; i < n; i++)
        {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
    void calculate()
    {
        for (i = 0; i < n - 1; i++)
        {
            for (j = i + 1; j < n; j++)
            {
                if (arr[i] > arr[j])
                {
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                    
                }
            }
        }
        cout << "sorted array elements are: " << endl;
        for (i = 0; i < n; i++)
        {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
};
int main()
{
    Sorting obj;

    obj.input();
    obj.output();
    obj.calculate();

    return 0;
}