#include <iostream>
using namespace std;
class deleteArray
{
    int arr[10], n, i, j, val, index = 10;

public:
    void input()
    {
        cout << "The number of elements you want to enter in the array:" << endl;
        cin >> n;
        cout << "Enter thr elements:" << endl;
        for (i = 0; i < n; i++)
        {
            cin >> arr[i];
        }
        cout << "Enter the element you want to delete: " << endl;
        cin >> val;
    }
    void output()
    {
        cout << "Your array elements before element deletion are: " << endl;
        for (i = 0; i < n; i++)
        {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
    void calculate()
    {
        for (i = 0; i < index; i++)
        {
            if (arr[i] == val)
            {
                for (j = i; j < index - 1; j++)
                {
                    arr[j] = arr[j + 1];
                }
                n--;
                i--;
            }
        }
        cout << "Updated array is: " << endl;
        for (i = 0; i < n; i++)
        {
            cout << arr[i] <<" ";
        }
    }
};
int main()
{
    deleteArray obj;
    obj.input();
    obj.output();
    obj.calculate();

    return 0;
}