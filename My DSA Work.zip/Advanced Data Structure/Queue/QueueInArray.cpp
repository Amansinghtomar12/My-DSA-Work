#include <iostream>
using namespace std;
class Queue
{
    public:
    int *arr;
    int front;
    int rear;
    int size;
    Queue()
    {
        size = 1000;
        arr = new int[size];
        front = 0;
        rear = 0;
    }
    void enqueue(int data)
    {
        if (rear == size)
        {
            cout << "queue is full" << endl;
        }
        else
        {
            arr[rear] = data;
            rear++;
        }
    }
    int dequeue()
    {
        if (front == rear)
        {
            return -1;
        }
        else
        {
            int ans = arr[front];
            arr[front] = -1;
            front++;
            if (front == rear)
            {
                front = 0;
                rear = 0;
            }
            return ans;
        }
    }
    int front()
    {
        if (front == rear)
        {
            return -1;
        }
        else
        {
            return arr[front];
        }
    }
    bool isEmpty()
    {
        if (front == rear)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
};
int main() {
    Queue myQueue;

    // Enqueue elements into the queue
    myQueue.enqueue(1);
    myQueue.enqueue(2);
    myQueue.enqueue(3);

    // Display the front element
    cout << "Front element: " << myQueue.front() << endl;

    // Dequeue elements from the queue
    cout << "Dequeued element: " << myQueue.dequeue() << endl;
    cout << "Dequeued element: " << myQueue.dequeue() << endl;

    // Check if the queue is empty
    cout << "Is the queue empty? " << (myQueue.isEmpty() ? "Yes" : "No") << endl;

    // Enqueue more elements
    myQueue.enqueue(4);
    myQueue.enqueue(5);

    // Display the front element
    cout << "Front element: " << myQueue.front() << endl;

    // Dequeue elements from the queue
    cout << "Dequeued element: " << myQueue.dequeue() << endl;
    cout << "Dequeued element: " << myQueue.dequeue() << endl;

    // Check if the queue is empty
    cout << "Is the queue empty? " << (myQueue.isEmpty() ? "Yes" : "No") << endl;

    return 0;
}

