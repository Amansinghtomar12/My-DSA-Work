#include <iostream>
using namespace std;
class deleteArray
{
    int arr[10], i, n, shift, first;

public:
    void input()
    {
        cout << "The number of elements you want to enter in the array:" << endl;
        cin >> n;
        cout << "Enter thr elements:" << endl;
        for (int i = 0; i < n; i++)
        {
            cin >> arr[i];
        }
    }
    void output()
    {
        cout << "Your array elements before shifting are: " << endl;
        for (int i = 0; i < n; i++)
        {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
    void calculate()
    {
        first = arr[0];
        for (i = 1; i < n; i++)
        {
            arr[i - 1] = arr[i];
        }
        arr[n - 1] = first;
        cout << "Updated array is: " << endl;
        for (i = 0; i < n; i++)
        {
            cout << arr[i] << " ";
        }
    }
};
int main()
{
    deleteArray obj;
    obj.input();
    obj.output();
    obj.calculate();

    return 0;
}