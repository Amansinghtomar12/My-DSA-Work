#include <iostream>
using namespace std;

class Max
{
    int i, n, *arr, min;

public:
    void input()
    {
        cout << "Enter the size of your array: " << endl;
        cin >> n;

        // Dynamically allocate memory for the array
        arr = new int[n];

        cout << "Give your array elements:" << endl;

        for (i = 0; i < n; i++)
        {
            cin >> arr[i];
        }
    }

    void print()
    {
        cout << "Your array is: " << endl;

        for (i = 0; i < n; i++)
        {
            cout << arr[i] << " ";
        }

        cout << endl; // Add a newline after printing the array
    }

    void calculate()
    {
        min = arr[0];

        for (i = 1; i < n; i++)
        {
            if (arr[i] < min)
            {
                min = arr[i];
            }
        }

        cout << "Min element of your array is: " << min << endl; // Add a newline after printing the minimum element
    }

    // Destructor to release dynamically allocated memory
    ~Max()
    {
        delete[] arr;
    }
};

int main()
{
    Max obj;
    obj.input();
    obj.print();
    obj.calculate();

    return 0;
}
