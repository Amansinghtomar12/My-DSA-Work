#include <iostream>
using namespace std;
class deleteArray
{
    int arr[10], i, n, shift, last, k;

public:
    void input()
    {
        cout << "The number of elements you want to enter in the array:" << endl;
        cin >> n;
        cout << "Enter thr elements:" << endl;
        for (int i = 0; i < n; i++)
        {
            cin >> arr[i];
        }
    }
    void output()
    {
        cout << "Your array elements before shifting are: " << endl;
        for (int i = 0; i < n; i++)
        {
            cout << arr[i] << " ";
        }
        cout << endl;
        cout << "Number of elements you want to shift: " << endl;
        cin >> shift;
    }
    void calculate()
    { 
        for (k = 1; k <= shift; k++)
        {
            last = arr[n - 1];
            for (i = n-2; i >= 0; i--)
            {
                arr[i + 1] = arr[i];
            }
            arr[0] = last;
        }
        cout << "Updated array is: " << endl;
        for (i = 0; i < n; i++)
        {
            cout << arr[i] << " ";
        }
    }
};
int main()
{
    deleteArray obj;
    obj.input();
    obj.output();
    obj.calculate();

    return 0;
}